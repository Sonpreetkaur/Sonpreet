# Bank

## Objective
Develop a banking console application that lets the user view accounts, create new accounts, and deposit and withdraw money.
