# Numbers

## Objective
1. Use C# data types int, double, and string
2. Use C# branches and loops

