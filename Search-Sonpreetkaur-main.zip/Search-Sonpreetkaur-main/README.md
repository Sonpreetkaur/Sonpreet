# Search

## Objective
Using the provided files, develop a console application that allows the user to preform searches on a collection of numbers. For this project, you will need to work with lists, branches, loops, and LINQ. 