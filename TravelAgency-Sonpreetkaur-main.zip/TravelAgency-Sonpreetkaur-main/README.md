# Travel Agency

## Objective
Complete the Travel Agency console application allowing the user to view all itineraries, add a new itinerary, change an itinerary, and exit.
