# Dice

## Objective
Use what you have learned about HTML and CSS to create a set of six dice. Each die will display a different side of a traditional six-sided die. 
