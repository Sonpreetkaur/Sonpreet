# Pokedex

## Objective
Using the [PokeApi](https://pokeapi.co), you will design and develop a Pokedex web application that will display a gallery of Pokemon with images. Users should be able to choose to load more Pokemon, view details about a specific Pokemon, and mark Pokemon as "caught".


