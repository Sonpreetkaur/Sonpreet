# Tribute

## Objective
Use what you have learned about HTML and CSS to create a tribute page for a historical figure. You will choose a historical figure who's meaningful to you and create a webpage dedicated to them. 
